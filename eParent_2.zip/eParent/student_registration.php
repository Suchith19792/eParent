<?php require_once('Connections/inst.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) 
{
	move_uploaded_file($_FILES['pic']['tmp_name'], "st_pics/".$_POST['login'].".jpg");
	
  $insertSQL = sprintf("INSERT INTO students ( inst_key, login, password, first_name, second_name) VALUES ( %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['inst_key'], "int"),
                       GetSQLValueString($_POST['login'], "text"),
                       GetSQLValueString($_POST['password'], "text"),
                       GetSQLValueString($_POST['first_name'], "text"),
                       GetSQLValueString($_POST['second_name'], "text"));

  mysql_select_db($database_inst, $inst);
  $Result1 = mysql_query($insertSQL, $inst) or die(mysql_error());
}



mysql_select_db($database_inst, $inst);
$query_inst_names = "SELECT inst_key, inst_name FROM institutions";
$inst_names = mysql_query($query_inst_names, $inst) or die(mysql_error());
$row_inst_names = mysql_fetch_assoc($inst_names);
$totalRows_inst_names = mysql_num_rows($inst_names);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
</head>

<body>

<p>&nbsp;</p>
<form  action="<?php echo $editFormAction; ?>" method="post" enctype="multipart/form-data" name="form1" id="form1">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Institution:</td>
      <td><select name="inst_key">
        <?php 
do {  
?>
        <option value="<?php echo $row_inst_names['inst_key']?>" ><?php echo $row_inst_names['inst_name']?></option>
        <?php
} while ($row_inst_names = mysql_fetch_assoc($inst_names));
?>
      </select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Login:</td>
      <td><span id="sprytextfield1">
        <input type="text" name="login" value="" size="32" />
      <span class="textfieldRequiredMsg">Feild is required.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Password:</td>
      <td><span id="sprytextfield2">
        <input type="password" name="password" value="" size="32" />
      <span class="textfieldRequiredMsg">Feild is required.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">First_name:</td>
      <td><span id="sprytextfield3">
        <input type="text" name="first_name" value="" size="32" />
      <span class="textfieldRequiredMsg">Feild is required.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Second_name:</td>
      <td><input type="text" name="second_name" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Picture</td>
      <td><label for="pic"></label>
      <input type="file" name="pic" id="pic" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Insert record" /></td>
    </tr>
  </table>
  <input type="hidden" name="MM_insert" value="form1" />
</form>
<p>&nbsp;</p>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3");
</script>
</body>
</html>
<?php
mysql_free_result($inst_names);
?>
